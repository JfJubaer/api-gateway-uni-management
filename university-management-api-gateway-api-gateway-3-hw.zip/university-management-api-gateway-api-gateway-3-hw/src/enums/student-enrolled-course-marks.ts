export const ExamType = {
    MIDTERM: 'MIDTERM',
    FINAL: 'FINAL'
};
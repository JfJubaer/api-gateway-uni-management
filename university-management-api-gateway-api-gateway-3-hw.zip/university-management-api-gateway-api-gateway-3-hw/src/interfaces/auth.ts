export interface IAuthUser {
  id: string;
  role: string;
}
